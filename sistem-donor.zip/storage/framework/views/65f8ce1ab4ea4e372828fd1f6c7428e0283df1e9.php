<div class="row align-items-center">
    <div class="col-lg-6">
        <div class="breadcrumb-content">
            <div class="section-heading">
                <h2 class="sec__title font-size-30 text-white"><?php echo e($subTitle); ?></h2>
            </div>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-6 -->
    <div class="col-lg-6">
        <div class="breadcrumb-list text-right">
            <ul class="list-items">
                <?php if($title): ?>
                <li><?php echo e($title); ?></li>
                <?php endif; ?>

                <?php if($subTitle): ?>
                    <li><?php echo e($subTitle); ?></li>
                <?php endif; ?>
            </ul>
        </div><!-- end breadcrumb-list -->
    </div><!-- end col-lg-6 -->
</div><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/layoutAdmin/breadcrumb.blade.php ENDPATH**/ ?>