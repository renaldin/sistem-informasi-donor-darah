

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12" data-aos="fade-up">
            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
                </div>
                <?php if(session('berhasil')): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <?php echo e(session('berhasil')); ?>

                    </div>
                <?php endif; ?>
                <div class="table-responsive p-3">
                    <table cellpadding='8' class="mb-2">
                        <tr>
                            <td>NIK</td>
                            <td>:</td>
                            <td><?php echo e($detail->nik); ?></td>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($detail->jenis_kelamin); ?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo e($detail->nama_anggota); ?></td>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo e($detail->alamat); ?></td>
                        </tr>
                    </table>
                    <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($row->tanggal_donor); ?></td>
                                    <td>
                                    <?php if($row->status_donor  === 'Ready'): ?>
                                        Proses Input Darah
                                    <?php elseif($row->status_donor  === 'Proses'): ?>
                                        Proses Cek Kesehatan
                                    <?php elseif($row->status_donor  === 'Selesai'): ?>
                                        Selesai
                                    <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/donatur/v_riwayat_donor.blade.php ENDPATH**/ ?>