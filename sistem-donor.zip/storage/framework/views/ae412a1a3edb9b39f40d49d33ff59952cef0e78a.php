

<?php $__env->startSection('content'); ?>
<section class="info-area padding-top-50px padding-bottom-70px">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 responsive-column">
                <div class="card box-shadow" style="box-shadow: 3px 3px 3px #e8e7e7;">
                    <div class="card-header">
                        <div>
                            <h5 class="modal-title title" id="exampleModalLongTitle">Reset Password</h5>
                            <p class="font-size-14">Hallo <?php echo e($dataUser->nama); ?>, silahkan ubah dengan password baru!</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="contact-form-action">
                            <form action="/ubah-password" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php if(session('berhasil')): ?>
                                        <div class="col-lg-12">
                                            <div class="alert bg-primary text-white alert-dismissible">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                                <?php echo e(session('berhasil')); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session('gagal')): ?>
                                        <div class="col-lg-12">
                                            <div class="alert bg-danger text-white alert-dismissible">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                <h4><i class="icon fa fa-ban"></i> Gagal!</h4>
                                                <?php echo e(session('gagal')); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text">Password Baru</label>
                                            <div class="form-group">
                                                <span class="la la-envelope form-icon"></span>
                                                <input class="form-control" type="hidden" name="id_member" value="<?php echo e($dataUser->id_member); ?>">
                                                <input class="form-control" type="password" name="password" placeholder="Masukkan Password Baru" value="<?php echo e(old('password')); ?>" autofocus>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text">Konfirmasi Password</label>
                                            <div class="form-group">
                                                <span class="la la-envelope form-icon"></span>
                                                <input class="form-control" type="password" name="password_confirmation" placeholder="Masukkan Konfirmasi Password" value="<?php echo e(old('password_confirmation')); ?>">
                                            </div>
                                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                </div>
                                <div class="btn-box pt-3 pb-4">
                                    <center>
                                        <button type="submit" class="theme-btn w-50">Simpan</button>
                                    </center>
                                </div>
                            </form>
                        </div><!-- end contact-form-action -->
                    </div>
                </div>
            </div>
        </div><!-- end row -->
    </div><!-- end container -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutUser.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/auth/resetPassword.blade.php ENDPATH**/ ?>