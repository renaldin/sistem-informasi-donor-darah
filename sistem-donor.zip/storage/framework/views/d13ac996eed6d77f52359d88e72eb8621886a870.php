<div class="input-box">
    <div class="form-group select-contain w-100">
        <input type="hidden" name="cetak" value="order">
        <select class="select-contain-select" class="form-control" name="dataKolom" id="dataKolom" >
            <option value="">--Pilih--</option>
            <?php $__currentLoopData = $dataKolom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($type === 'id_member'): ?>
                <option value="<?php echo e($item->id_member); ?>"><?php echo e($item->nama); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/order/dataKolom.blade.php ENDPATH**/ ?>