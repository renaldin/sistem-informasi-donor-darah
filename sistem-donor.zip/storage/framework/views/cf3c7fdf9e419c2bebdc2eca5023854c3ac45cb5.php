

<?php $__env->startSection('content'); ?>

<!-- ================================
    START USER AREA
================================= -->
<section class="user-area padding-top-100px padding-bottom-60px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
               <h3 class="title font-size-24">Profil Saya</h3>
                <div class="card-item user-card card-item-list mt-4 mb-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <img class="user-pro-img" style="width: 8rem;" src="<?php if($user->foto_user): ?><?php echo e(asset('foto_user/'.$user->foto_user)); ?> <?php else: ?> <?php echo e(asset('foto_user/default1.jpg')); ?> <?php endif; ?>" alt=""><br><br>
                                <h3 class="card-title"><?php echo e($user->nama); ?></h3>
                                <p class="card-meta">Member sejak <?php echo e(date('d F Y', strtotime($user->tanggal_daftar))); ?></p>
                                <div class="d-flex justify-content-between pt-3">
                                    <ul class="list-items list-items-2 flex-grow-1">
                                        <li><span>Email:</span><?php echo e($user->email); ?></li>
                                        <li><span>Nomor Telepon:</span><?php echo e($user->nomor_telepon); ?></li>
                                        <li><span>Alamat:</span><?php echo e($user->alamat); ?></li>
                                        <li><span>Nama Perusahaan:</span><?php echo e($user->nama_perusahaan); ?></li>
                                        <li><span>Alamat Perusahaan:</span><?php echo e($user->alamat_perusahaan); ?></li>
                                        <li><span>Logo Perusahaan:</span><img class="user-pro-img" style="width: 8rem;" src="<?php if($user->foto_perusahaan): ?><?php echo e(asset('foto_perusahaan/'.$user->foto_perusahaan)); ?> <?php else: ?> <?php echo e(asset('foto_perusahaan/default1.jpg')); ?> <?php endif; ?>" alt=""></li>
                                    </ul>
                                </div>
                                <div class="d-flex justify-content-between pt-3">
                                    <a href="/ubah-password/<?php echo e($user->id_member); ?>" class="theme-btn">Ubah Password</a>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <h3 class="card-title">Edit Profil</h3>
                                <p class="card-meta">Jika Anda ingin melakukan edit profil dapat dilakukan di form bawah ini!</p>
                                <div class="d-flex justify-content-between pt-3">
                                    <div class="form-content">
                                        <div class="contact-form-action">
                                            <form action="/edit-profil-user/<?php echo e($user->id_member); ?>" method="Post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="mb-2">
                                                            <?php if(session('berhasil')): ?>    
                                                                <div class="alert bg-primary text-white alert-dismissible">
                                                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                    <?php echo e(session('berhasil')); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if(session('gagal')): ?>    
                                                                <div class="alert bg-primary text-white alert-dismissible">
                                                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                                    <?php echo e(session('gagal')); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Nama Lengkap</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="text" name="nama" placeholder="Masukkan Nama Lengkap" value="<?php echo e($user->nama); ?>" autofocus>
                                                            </div>
                                                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">No. Telepon</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="text" name="nomor_telepon" placeholder="Masukkan Nomor Telepon" value="<?php echo e($user->nomor_telepon); ?>">
                                                            </div>
                                                            <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Alamat</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="text" name="alamat" placeholder="Masukkan Alamat" value="<?php echo e($user->alamat); ?>">
                                                            </div>
                                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Nama Perusahaan</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="text" name="nama_perusahaan" placeholder="Masukkan Nama Perusahaan" value="<?php echo e($user->nama_perusahaan); ?>">
                                                            </div>
                                                            <?php $__errorArgs = ['nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Alamat Perusahaan</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="text" name="alamat_perusahaan" placeholder="Masukkan Alamat Perusahaan" value="<?php echo e($user->alamat_perusahaan); ?>">
                                                            </div>
                                                            <?php $__errorArgs = ['alamat_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Email</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="email" name="email" placeholder="Masukkan Email" value="<?php echo e($user->email); ?>">
                                                            </div>
                                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>          
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Logo Perusahaan</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="file" name="foto_perusahaan">
                                                            </div>
                                                            <?php $__errorArgs = ['foto_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>          
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text"></label>
                                                            <div class="form-group">
                                                                <img src="<?php if($user->foto_perusahaan): ?><?php echo e(asset('foto_perusahaan/'.$user->foto_perusahaan)); ?> <?php else: ?> <?php echo e(asset('foto_perusahaan/default1.jpg')); ?> <?php endif; ?>" style="width:60%;" alt="">
                                                            </div>
                                                        </div>          
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text">Foto Anda</label>
                                                            <div class="form-group">
                                                                <span class="la la-circle form-icon"></span>
                                                                <input class="form-control" type="file" name="foto_user">
                                                            </div>
                                                            <?php $__errorArgs = ['foto_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div style="margin-top: -16px">
                                                                <small class="text-danger"><?php echo e($message); ?></small>
                                                            </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>          
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="input-box">
                                                            <label class="label-text"></label>
                                                            <div class="form-group">
                                                                <img src="<?php if($user->foto_user): ?><?php echo e(asset('foto_user/'.$user->foto_user)); ?> <?php else: ?> <?php echo e(asset('foto_user/default1.jpg')); ?> <?php endif; ?>" style="width:60%;" alt=""> 
                                                            </div>
                                                        </div>          
                                                    </div>
                                                </div>
                                                <div class="btn-box pt-3 pb-4">
                                                    <center>
                                                        <button type="submit" class="theme-btn w-50">Simpan</button>
                                                    </center>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- end card-item -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end user-area -->
<!-- ================================
    END USER AREA
================================= -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutUser.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/user/profil/profil.blade.php ENDPATH**/ ?>