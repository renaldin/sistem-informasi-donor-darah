

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
            </div>
            <div class="card-header flex flex-row">
                <a href="/tambah_user" class="btn btn-primary">Tambah</a>
            </div>
            <div class="table-responsive p-3">
                
                <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap</th>
                            <th>Nomor Telepon</th>
                            <th>Role</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1;?>
                        <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->id_user !== $row->id_user): ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->nomor_telepon); ?></td>
                                <td>
                                    <?php if($row->role === 'Donatur'): ?>
                                        <span class="badge badge-danger"><?php echo e($row->role); ?></span>
                                        <?php elseif($row->role === 'Event'): ?>    
                                        <span class="badge badge-primary"><?php echo e($row->role); ?></span>
                                        <?php elseif($row->role === 'Petugas Kesehatan'): ?>    
                                        <span class="badge badge-warning"><?php echo e($row->role); ?></span>
                                        <?php elseif($row->role === 'Rumah Sakit'): ?>    
                                        <span class="badge badge-success"><?php echo e($row->role); ?></span>
                                        <?php elseif($row->role === 'Pusat PMI'): ?>    
                                        <span class="badge badge-info"><?php echo e($row->role); ?></span>
                                        <?php elseif($row->role === 'Admin'): ?>    
                                        <span class="badge badge-secondary"><?php echo e($row->role); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <img class="img-profile rounded-circle" style="width: 50px;" src="<?php if($row->foto === null): ?> <?php echo e(asset('foto_user/default.jpg')); ?> <?php else: ?> <?php echo e(asset('foto_user/'.$row->foto)); ?> <?php endif; ?>" alt="profile">
                                </td>
                                <td>
                                    <a href="/edit_user/<?php echo e($row->id_user); ?>" class="btn btn-sm btn-success">Edit</a>
                                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapus<?php echo e($row->id_user); ?>">Hapus</button>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="hapus<?php echo e($row->id_user); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <p>Apakah Anda yakin akan hapus data ini?</p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Batal</button>
      <a href="/hapus_user/<?php echo e($row->id_user); ?>" class="btn btn-danger">Hapus</a>
    </div>
  </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/admin/user/v_index.blade.php ENDPATH**/ ?>