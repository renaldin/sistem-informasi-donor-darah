<div class="row align-items-center">
    <div class="col-lg-7">
        <div class="copy-right padding-top-30px">
            <p class="copy__desc">
                &copy; Copyright Sistem Booking Reklame Billboard <?php echo e(date('Y')); ?>. di desain oleh
                 <a href="/">Admin Sistem Booking Billboard</a>
            </p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/layoutAdmin/footer.blade.php ENDPATH**/ ?>