<div class="sidebar-nav sidebar--nav">
    <div class="sidebar-nav-body">
        <div class="author-content">
            <div class="d-flex align-items-center">
                <div class="author-img avatar-sm">
                    <img src="<?php if($user->foto): ?><?php echo e(asset('foto_user/'.$user->foto)); ?> <?php else: ?> <?php echo e(asset('foto_user/default1.jpg')); ?> <?php endif; ?>" alt="testimonial image">
                </div>
                <div class="author-bio">
                    <h4 class="author__title"><?php echo e($user->nama); ?></h4>
                    <span class="author__meta">Welcome to <?php echo e($user->role); ?> Panel</span>
                </div>
            </div>
        </div>
        <div class="sidebar-menu-wrap">
            <ul class="sidebar-menu toggle-menu list-items">
                <?php if(Session()->get('role') === 'Admin'): ?>
                <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardAdmin"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                <li class="<?php if($subTitle === 'Biodata Website'): ?> page-active <?php endif; ?>"><a href="/biodata-website"><i class="la la-laptop mr-2"></i>Biodata Web</a></li>
                <li class="<?php if($title === 'Data Pegawai'): ?> page-active <?php endif; ?>" ><a href="/kelola-pegawai"><i class="la la-user mr-2"></i>Data Pegawai</a></li>
                <li class="<?php if($title === 'Data Absensi'): ?> page-active <?php endif; ?>" ><a href="/kelola-absensi"><i class="la la-user mr-2"></i>Data Absensi</a></li>
                <li class="<?php if($title === 'Data Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/kelola-pengajuan-cuti"><i class="la la-user mr-2"></i>Data Pengajuan Cuti</a></li>
                <li class="<?php if($title === 'Data User'): ?> page-active <?php endif; ?>" ><a href="/kelola-user"><i class="la la-user mr-2"></i>Data User</a></li>
                <?php elseif(Session()->get('role') === 'Pegawai'): ?>
                <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardPegawai"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                <li class="<?php if($title === 'Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/pengajuan-cuti"><i class="la la-user mr-2"></i>Pengajuan Cuti</a></li>
                <?php elseif(Session()->get('role') === 'Wakil Direktur'): ?>
                <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardWadir"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                <li class="<?php if($title === 'Perizinan Cuti'): ?> page-active <?php endif; ?>" ><a href="/perizinan-cuti"><i class="la la-user mr-2"></i>Perizinan Cuti</a></li>
                <?php elseif(Session()->get('role') === 'Ketua Jurusan'): ?>
                <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardKajur"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                <li class="<?php if($title === 'Perizinan Cuti'): ?> page-active <?php endif; ?>" ><a href="/perizinan-cuti"><i class="la la-user mr-2"></i>Perizinan Cuti</a></li>
                <?php endif; ?>
                <li><a data-toggle="modal" data-target="#logout"><i class="la la-power-off mr-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>