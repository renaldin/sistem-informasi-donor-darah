

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
            </div>
            <div class="table-responsive p-3">
                <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                        <tr>
                            <th>No</th>
                            <th>Name Instansi</th>
                            <th>Waktu Event</th>
                            <th>Status Event</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1;?>
                        <?php $__currentLoopData = $data_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($row->status_event === 'Tidak Aktif' && $row->status_pengajuan === 'Disetujui'): ?>
                          <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->nama_instansi); ?></td>
                            <td><?php echo e($row->tanggal_event); ?> <?php echo e($row->jam); ?></td>
                            <td>
                                <?php if($row->status_event === 'Aktif'): ?>
                                    <span class="badge badge-success"><?php echo e($row->status_event); ?></span>
                                <?php elseif($row->status_event === 'Tidak Aktif'): ?>    
                                    <span class="badge badge-dabger"><?php echo e($row->status_event); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="/detail_event/<?php echo e($row->id_event); ?>" class="btn btn-sm btn-info">Detail</a>  
                            </td>
                          </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/admin/pengajuan_event/v_riwayat.blade.php ENDPATH**/ ?>