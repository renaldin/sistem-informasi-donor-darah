

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="form-title-wrap">
                                <div>
                                    <h3 class="title"><?php echo e($subTitle); ?></h3>
                                    <p class="font-size-14">Silahkan kelola data order di tabel bawah!</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="cart-totals table-form">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="text-center">Menunggu Harga</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">
                                                <div class="table-content">
                                                    <center><h3 class="title"><?php echo e($jumlahTungguHarga); ?></h3></center>
                                                </div>
                                            </th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-content">
                        <div class="table-form table-responsive">
                            <div class="mb-2">
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cetakMember"><i class="la la-print"></i> Member</button>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cetakReklame"><i class="la la-print"></i> Reklame</button>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cetakTanggal"><i class="la la-print"></i> Tanggal</button>
                            </div>
                            <div class="mb-2">
                                <?php if(session('berhasil')): ?>    
                                    <div class="alert bg-primary text-white alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                        <?php echo e(session('berhasil')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <table class="table" id="example2">
                                <thead>
                                    <tr>
                                        <th scope="col">ID Pesanan</th>
                                        <th scope="col">Member</th>
                                        <th scope="col">Reklame</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Harga</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;?>
                                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($item->id_pesanan); ?></th>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->lokasi); ?></td>
                                            <td><?php echo e(date('d F Y', strtotime($item->tanggal))); ?></td>
                                            <td>
                                                <?php if($item->harga === NULL): ?>
                                                    Menunggu Harga <br>
                                                    
                                                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#tambahBeriHarga<?php echo e($item->id_pesanan); ?>">Beri Harga</button>
                                                <?php else: ?>
                                                    <?= 'Rp ' . number_format($item->harga, 2, ',', '.'); ?> <br>
                                                    
                                                    <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#editBeriHarga<?php echo e($item->id_pesanan); ?>">Edit Harga</button>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($item->status_order === 'Batal'): ?>
                                                    <span class="badge badge-danger"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Dibooking'): ?>
                                                    <span class="badge badge-info"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Dibayar'): ?>
                                                    <span class="badge badge-success"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Approve/Tayang'): ?>
                                                    <span class="badge badge-warning"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Selesai'): ?>
                                                    <span class="badge badge-primary"><?php echo e($item->status_order); ?></td></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="table-content text-center">
                                                    <a href="/download-detail/<?php echo e($item->id_pesanan); ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Download"><i class="la la-download"></i></a>
                                                    <a href="/detail-order/<?php echo e($item->id_pesanan); ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></a>
                                                    <button type="button" class="theme-btn theme-btn-small mb-1" data-toggle="modal" data-target="#hapus<?php echo e($item->id_pesanan); ?>" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="la la-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Modal -->
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        <?php echo $__env->make('layoutAdmin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>


<div class="modal fade" id="cetakMember"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cetak Berdasarkan Member</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <div class="modal-body">
            <form action="/cetak-pdf-order" method="POST">
                <?php echo csrf_field(); ?>
                <div class="contact-form-action">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Pilih Member</label>
                                <div class="form-group">
                                    <span class="la la-calendar form-icon"></span>
                                    <input type="hidden" name="cetakOrder" value="Member">
                                    <div class="form-group select-contain w-100">
                                        <select class="select-contain-select" name="id_member">
                                            <?php $__currentLoopData = $dataMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_member); ?>"><?php echo e($item->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Cetak</button>
        </div>
        </form>
        </div>
    </div>
</div>
<div class="modal fade" id="cetakReklame"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cetak Berdasarkan Reklame</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <div class="modal-body">
            <form action="/cetak-pdf-order" method="POST">
                <?php echo csrf_field(); ?>
                <div class="contact-form-action">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Pilih Reklame</label>
                                <div class="form-group">
                                    <span class="la la-calendar form-icon"></span>
                                    <input type="hidden" name="cetakOrder" value="Reklame">
                                    <div class="form-group select-contain w-100">
                                        <select class="select-contain-select" name="id_reklame">
                                            <?php $__currentLoopData = $dataReklame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_reklame); ?>"><?php echo e($item->lokasi); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Cetak</button>
        </div>
        </form>
        </div>
    </div>
</div>
<div class="modal fade" id="cetakTanggal"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cetak Berdasarkan Tanggal</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <div class="modal-body">
            <form action="/cetak-pdf-order" method="POST">
                <?php echo csrf_field(); ?>
                <div class="contact-form-action">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Pilih Tanggal</label>
                                <div class="form-group">
                                    <span class="la la-calendar form-icon"></span>
                                    <input type="hidden" name="cetakOrder" value="Tanggal">
                                    <div class="form-group select-contain w-100">
                                        <select class="select-contain-select" name="tanggal">
                                            <?php $__currentLoopData = $dataTanggal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->tanggal); ?>"><?php echo e(date('d F Y', strtotime($item->tanggal))); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Cetak</button>
        </div>
        </form>
        </div>
    </div>
</div>



<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="tambahBeriHarga<?php echo e($item->id_pesanan); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-sm">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Beri Harga</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form action="/beri-harga/<?php echo e($item->id_pesanan); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="input-box">
                            <label class="label-text">Harga</label>
                            <div class="form-group">
                                <input class="form-control" type="number" name="harga" placeholder="Masukkan Harga" value="<?php echo e(old('harga')); ?>" required autofocus>
                            </div>
                            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="margin-top: -16px">
                                <small class="text-danger"><?php echo e($message); ?></small>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
<div class="modal fade" id="editBeriHarga<?php echo e($item->id_pesanan); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-sm">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Harga</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form action="/beri-harga/<?php echo e($item->id_pesanan); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="input-box">
                            <label class="label-text">Harga</label>
                            <div class="form-group">
                                <input class="form-control" type="number" name="harga" placeholder="Masukkan Harga" value="<?php echo e($item->harga); ?>" required autofocus>
                            </div>
                            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="margin-top: -16px">
                                <small class="text-danger"><?php echo e($message); ?></small>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-success">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="hapus<?php echo e($item->id_pesanan); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <p>Apakah Anda yakin akan hapus data ini ?</p>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <a href="/hapus-order/<?php echo e($item->id_pesanan); ?>" class="btn btn-danger">Hapus</a>
        </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/order/dataOrder.blade.php ENDPATH**/ ?>