

<?php $__env->startSection('content'); ?>

<?php
function hitungUmur($tanggal_darah_masuk) {
  $tgl_lahir = new DateTime($tanggal_darah_masuk);
  $sekarang = new DateTime();
  $diff = $tgl_lahir->diff($sekarang);
  $umur = $diff->days;

  $data_umur = $umur.' hari.';
  return $data_umur;
}
?>

<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
            </div>
            <div class="table-responsive p-3">
                <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                        <tr>
                            <th>No</th>
                            <th>Nama RS</th>
                            <th>Tanggal</th>
                            <th>Golda</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1;?>
                        <?php $__currentLoopData = $data_permohonan_darah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($row->status_permohonan == 'Diterima'): ?>
                          <tr>
                              <td><?php echo e($no++); ?></td>
                              <td><?php echo e($row->nama_rs); ?></td>
                              <td><?php echo e($row->tanggal_permohonan); ?></td>
                              <td><?php echo e($row->golda); ?></td>
                              <td><?php echo e($row->jumlah); ?></td>
                              <td>
                                <button type="button" class="btn btn-xm btn-info" data-toggle="modal" data-target="#detail<?php echo e($row->id_permohonan_darah); ?>">Detail</button>   
                              </td>
                          </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->

<?php $__currentLoopData = $data_permohonan_darah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detail<?php echo e($row->id_permohonan_darah); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Detail</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <div class="row">
        <div class="col-lg-12">
            <table>
                <tr>
                    <th>Nama Rumah Sakit</th>
                    <td>:</td>
                    <td><?php echo e($row->nama_rs); ?></td>
                </tr>
                <tr>
                  <th>Nama Dokter</th>
                  <td>:</td>
                  <td><?php echo e($row->nama_dokter); ?></td>
                </tr>
                <tr>
                    <th>Nama Pasien</th>
                    <td>:</td>
                    <td><?php echo e($row->nama_pasien); ?></td>
                </tr>
                <tr>
                    <th>Tanggal Permohonan</th>
                    <td>:</td>
                    <td><?php echo e($row->tanggal_permohonan); ?></td>
                </tr>
                <tr>
                  <th>Golongan Darah</th>
                  <td>:</td>
                  <td><?php echo e($row->golda); ?></td>
              </tr>
                <tr>
                    <th>Jumlah {Kantong}</th>
                    <td>:</td>
                    <td><?php echo e($row->jumlah); ?></td>
                </tr>
                <tr>
                    <th>Status Permohonan</th>
                    <td>:</td>
                    <td>
                        <?php if($row->status_permohonan === 'Belum Dikirim'): ?>
                            <span class="badge badge-danger"><?php echo e($row->status_permohonan); ?></span>
                            <?php elseif($row->status_permohonan === 'Menunggu Proses'): ?>    
                            <span class="badge badge-primary"><?php echo e($row->status_permohonan); ?></span>
                            <?php elseif($row->status_permohonan === 'Diterima'): ?>    
                            <span class="badge badge-success"><?php echo e($row->status_permohonan); ?></span>
                            <?php elseif($row->status_permohonan === 'Dikirim'): ?>    
                            <span class="badge badge-warning"><?php echo e($row->status_permohonan); ?></span>
                        <?php endif; ?>    
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-lg-12 mt-2">
          <div class="table-responsive p-3">
              <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                  <thead class="thead-light">
                      <tr>
                          <th>No</th>
                          <th>No Kantung</th>
                          <th>Golongan Darah</th>
                          <th>Resus</th>
                          <th>Umur</th>
                          <th>Tanggal Kedaluwarsa</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $no=1;?>
                      <?php $__currentLoopData = $data_darah_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($row->id_permohonan_darah == $item->id_permohonan_darah): ?>
                        <tr>
                          <td><?php echo e($no++); ?></td>
                          <td><?php echo e($item->no_kantong); ?></td>
                          <td><?php echo e($item->golongan_darah); ?></td>
                          <td><?php echo e($item->resus); ?></td>
                          <td><?php echo e(hitungUmur($item->tanggal_darah_masuk)); ?></td>
                          <td><?php echo e($item->tanggal_kedaluwarsa); ?></td>
                        </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
      </div>
        <div class="col-lg-12 mt-3">
            <label for="upload_surat"><strong>Surat</strong></label>
            <iframe src="<?php echo e(asset('surat_permohonan_darah/'.$row->upload_surat)); ?>" frameborder="0" scrolling="auto" width="100%" height="500px"></iframe>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-danger" data-dismiss="modal">Kembali</button>
    </div>
  </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/rumah_sakit/permohonan_darah/v_riwayat.blade.php ENDPATH**/ ?>