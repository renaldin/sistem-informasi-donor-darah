

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-lg-12" data-aos="fade-up">
            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
                </div>
                <div class="table-responsive p-3">
                    <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $data_donor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($row->nama_anggota); ?></td>
                                    <td><?php echo e($row->jenis_kelamin); ?></td>
                                    <td><?php echo e($row->alamat); ?></td>
                                    <td><?php echo e($row->tanggal_donor); ?></td>
                                    <td><span
                                            class="badge badge-<?php echo e($row->status_donor == 'Proses' ? 'warning' : ''); ?><?php echo e($row->status_donor == 'Ready' ? 'info' : ''); ?><?php echo e($row->status_donor == 'Selesai' ? 'success' : ''); ?>"><?php echo e($row->status_donor); ?></span>
                                    </td>
                                    <td class="text-center">
                                        <?php if($row->status_donor == 'Selesai' || $row->status_donor == 'Ready'): ?>
                                        <?php elseif($row->status_donor == 'Proses' && $row->hb != null): ?>
                                            <a href="/cek_kesehatan/<?php echo e($row->id_donor); ?>/show"
                                                class="btn btn-primary btn-sm">Lihat</a>
                                            <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                data-target="#validasi<?php echo e($row->id_donor); ?>">Validasi</button>
                                        <?php else: ?>
                                            <a href="/cek_kesehatan/<?php echo e($row->id_donor); ?>" class="btn btn-info btn-sm">Cek
                                                Kesehatan</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $data_donor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="validasi<?php echo e($row->id_donor); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Validas</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda Ingin Melakukan Validasi <?php echo e($row->nama_anggota); ?>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Batal</button>
                        <a href="/validasi/<?php echo e($row->id_donor); ?>" class="btn btn-danger">Validasi</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/petugas_kesehatan/antrian/v_index.blade.php ENDPATH**/ ?>