<aside id="sidebar" class="sidebar">
  <div class="sidebar-img">
  <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-heading">Dashboard</li>
    <li class="nav-item">
      <a class="nav-link <?php echo e($subTitle === 'Dashboard' ? '':'collapsed'); ?>" href="<?php if($user->role === 'Admin'): ?> /dashboardAdmin <?php elseif($user->role === 'Pegawai'): ?> /dashboardPegawai <?php elseif($user->role === 'Wakil Direktur'): ?> /dashboardWadir <?php elseif($user->role === 'Ketua Jurusan'): ?> /dashboardKajur <?php endif; ?>">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <?php if($user->role === 'Admin'): ?>
    <li class="nav-heading">Master Data</li>
    <li class="nav-item">
      <a class="nav-link <?php echo e($subTitle === 'Pengaturan Web' ? '':'collapsed'); ?>" href="/pengaturan-web">
        <i class="bi bi-people"></i>
        <span>Pengaturan Web</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?php echo e($subTitle === 'Users' ? '':'collapsed'); ?>" href="">
        <i class="bi bi-people"></i>
        <span>Kelola User</span>
      </a>
    </li>
    <?php endif; ?>
  </ul>
</div>
</aside><?php /**PATH C:\xampp\htdocs\spp\resources\views/layout/v_sidebar.blade.php ENDPATH**/ ?>