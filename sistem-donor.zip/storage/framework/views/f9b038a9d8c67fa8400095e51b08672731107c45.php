

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-6">
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              <h6 class="m-0 font-weight-bold"><?php echo e($sub_title); ?></h6>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-center">
                <img class="img-profile rounded-circle" style="width: 120px;" src="<?php if($user->foto === null): ?> <?php echo e(asset('foto_user/default.jpg')); ?> <?php else: ?> <?php echo e(asset('foto_user/'.$user->foto)); ?> <?php endif; ?>" alt="profile">
            </div>
            <div class="card-header d-flex flex-row align-items-center justify-content-center">
                <h6 class="m-0 font-weight-bold"><?php echo e($user->nama); ?></h6>
            </div>
            <div class="card-body">
                <?php if($user->role === 'Event'): ?>
                <div class="form-group">
                    <label>Kode Instansi : <?php echo e($user->kode_instansi); ?></label>
                </div>
                <?php endif; ?>
                <?php if($user->role === 'Rumah Sakit'): ?>
                <div class="form-group">
                    <label>Kode Rumah Sakit : <?php echo e($user->kode_rs); ?></label>
                </div>
                <?php endif; ?>
                <?php if($user->role === 'Donatur'): ?>
                <div class="form-group">
                    <label>NIK : <?php echo e($user->nik); ?></label>
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin : <?php echo e($user->jk); ?></label>
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir : <?php echo e(date('d F Y', strtotime($user->tanggal_lahir))); ?></label>
                </div>
                <div class="form-group">
                    <label>Golongan Darah : <?php echo e($user->gol_darah ? $user->gol_darah : '-'); ?></label>
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label>Nomor Telepon : <?php echo e($user->nomor_telepon); ?></label>
                </div>
                <div class="form-group">
                    <label>Email : <?php echo e($user->email); ?></label>
                </div>
                <div class="form-group">
                    <label>Alamat : <?php echo e($user->alamat_user); ?></label>
                </div>
                <div class="form-group">
                    <label>Status : <?php echo e($user->role); ?></label>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
    <div class="card mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h6 class="m-0 font-weight-bold">Form Edit Profil</h6>
        </div>
        <div class="card-body">
            <form action="/edit_profil/<?php echo e($user->id_user); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">

                <?php if($user->role === 'Event'): ?>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="kode_instansi">Kode Instansi</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['kode_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_instansi" id="kode_instansi" value="<?php echo e($user->kode_instansi); ?>" placeholder="Masukkan Kode Instansi" required>
                            <?php $__errorArgs = ['kode_instansi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                <?php endif; ?>

                <?php if($user->role === 'Rumah Sakit'): ?>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="kode_rs">Kode Rumah Sakit</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['kode_rs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_rs" id="kode_rs" value="<?php echo e($user->kode_rs); ?>" placeholder="Masukkan Kode Rumah Sakit" required>
                            <?php $__errorArgs = ['kode_rs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                <?php endif; ?>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="nama"><?php if($user->role === 'Event'): ?> Nama Instansi <?php elseif($user->role === 'Rumah Sakit'): ?> Nama Rumah Sakit <?php else: ?> Nama Lengkap <?php endif; ?></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" id="nama" value="<?php echo e($user->nama); ?>" placeholder="Masukkan Nama Lengkap">
                        <input type="hidden" class="form-control" name="role" value="<?php echo e($user->role); ?>">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>       
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="nama">Alamat</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['alamat_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_user" id="alamat_user" value="<?php echo e($user->alamat_user); ?>" placeholder="Masukkan Alamat">
                        <?php $__errorArgs = ['alamat_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>       
                </div>

                <?php if($user->role === 'Donatur'): ?>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik" id="nik" value="<?php echo e($user->nik); ?>" placeholder="Masukkan NIK" required>
                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="tanggal_lahir">Tanggal Lahir</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo e($user->tanggal_lahir); ?>" placeholder="Masukkan Tanggal Lahir" required>
                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="jk">Jenis Kelamin</label>
                            <select class="form-control <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jk" required>
                                <?php if($user->jk): ?>
                                    <option value="<?php echo e($user->jk); ?>"><?php echo e($user->jk); ?></option>
                                <?php else: ?>
                                    <option value="">-- Pilih --</option>
                                <?php endif; ?>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                            <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="gol_darah">Golongan Darah</label>
                            <select class="form-control <?php $__errorArgs = ['gol_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gol_darah">
                                <?php if($user->gol_darah): ?>
                                    <option value="<?php echo e($user->gol_darah); ?>"><?php echo e($user->gol_darah); ?></option>
                                <?php else: ?>
                                    <option value="">-- Pilih --</option>
                                <?php endif; ?>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="AB">AB</option>
                                <option value="O">O</option>
                            </select>
                            <?php $__errorArgs = ['gol_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>       
                    </div>
                <?php endif; ?>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="nomor_telepon">Nomor Telepon</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nomor_telepon" id="nomor_telepon" value="<?php echo e($user->nomor_telepon); ?>" placeholder="Masukkan Nomor Telepon">
                        <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>       
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" value="<?php echo e($user->email); ?>" placeholder="Masukkan Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>       
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="foto">Foto</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="foto">
                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-text text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-lg-12 mt-5">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
          </div>
        </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-donor\resources\views/profil/v_index.blade.php ENDPATH**/ ?>